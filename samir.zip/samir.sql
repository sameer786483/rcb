create database restaurent14;
use restaurent14;
create table chief(
cname varchar(20) not null,
csalary decimal(18,2),
cid int primary key);
create table meal(
mname varchar(20) not null,
mprice decimal(18,2),
cid int);
create table supplier(
sname varchar(20)not null,
scity varchar(20),
sid int);
alter table meal add constraint fk1 foreign key (cid)references chief (cid);
insert into chief values("suresh",12000.00,10);
insert into chief values("ramesh",13000.00,20);
insert into chief values("vinay",15000.00,50);
insert into meal values("idli",40,10);
insert into meal values("dosa",60,20);
insert into supplier values("vijay","davangere",30);
insert into supplier values("guru","harihara",40);
select * from chief;
select* from meal;
select* from supplier;
alter table chief add age int;
update chief set age=34 where cid=50;
select*from chief where not age=24;
select*from chief;
select chief.csalary,meal.mname from chief left join meal on chief.cid=meal.cid;



